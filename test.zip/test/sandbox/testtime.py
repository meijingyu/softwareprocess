'''
Created on Oct 12, 2016

@author: apple
'''
import time

time1=time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(time.time()))
print(time1)
        